package tic.tac.toe;
/**
 *
 * @author Ramlah Munir
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe extends JFrame implements ActionListener {
    // Components of the GUI
    private JButton[] buttons = new JButton[9];
    private JLabel label;
    private String currentPlayer = "X";

    // Game state variables
    private String[] board = new String[9];
    private boolean gameOver = false;

    public TicTacToe() {
        setTitle("Tic Tac Toe");
        setLayout(new BorderLayout());
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Label for displaying current player
        label = new JLabel("Player X's Turn", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        add(label, BorderLayout.NORTH);

        // Game board panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 3));
        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton();
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 60));
            buttons[i].setFocusPainted(false);
            buttons[i].addActionListener(this);
            panel.add(buttons[i]);
        }
        add(panel, BorderLayout.CENTER);


        // Initialize the game board
        for (int i = 0; i < 9; i++) {
            board[i] = ""; // Empty initially
        }

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameOver) return;

        JButton clickedButton = (JButton) e.getSource();
        int index = -1;
        for (int i = 0; i < 9; i++) {
            if (buttons[i] == clickedButton) {
                index = i;
                break;
            }
        }

        // If the clicked button is already occupied, return
        if (!board[index].equals("")) return;

        // Set image based on the current player
        if (currentPlayer.equals("X")) {
            clickedButton.setText("X");
            board[index] = "X";
            currentPlayer = "O";
            label.setText("Player O's Turn");
        } else {
            clickedButton.setText("O");
            board[index] = "O";
            currentPlayer = "X";
            label.setText("Player X's Turn");
        }

        // Check for a winner
        checkWinner();
    }

    private void checkWinner() {
        // Winning combinations (index positions)
        int[][] winningCombinations = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
            {0, 4, 8}, {2, 4, 6}  // Diagonals
        };

        for (int[] combination : winningCombinations) {
            String a = board[combination[0]];
            String b = board[combination[1]];
            String c = board[combination[2]];

            if (!a.equals("") && a.equals(b) && a.equals(c)) {
                gameOver = true;
                label.setText("Player " + a + " Wins!");
                return;
            }
        }

        // Check for a draw
        boolean isDraw = true;
        for (String cell : board) {
            if (cell.equals("")) {
                isDraw = false;
                break;
            }
        }
        if (isDraw) {
            gameOver = true;
            label.setText("It's a Draw!");
        }
    }

    public static void main(String[] args) {
        new TicTacToe();
    }

}
